package app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import apiario.ProjectWork_ApiarioApplication;

@SpringBootTest(classes = ProjectWork_ApiarioApplication.class)
class ProjectWork_ApiarioApplicationTests {
	
	@Test
	void contextLoads() {
		
	}

}
