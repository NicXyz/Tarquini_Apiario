package apiario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWork_ApiarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWork_ApiarioApplication.class, args);
	}

}
