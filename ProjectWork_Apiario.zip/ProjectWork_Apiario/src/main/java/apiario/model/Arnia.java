package apiario.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="arnia")
public class Arnia {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_arnia", nullable=true)
	private Integer idArnia;
	
	@Column(name = "tipo_regina")
	private String tipoRegina;
	
	@Column(name = "anno_regina")
	private Double annoRegina;

	@Column(name = "anno_acq")
	private Double annoAcq;
	
	@Column(name = "id_apiario")
	private Integer idApiario;
	
	@Column(name = "id_tipo_arnia")
	private Integer idTipoArnia;

	public Integer getIdArnia() {
		return idArnia;
	}
	public void setIdArnia(Integer idArnia) {
		this.idArnia = idArnia;
	}
	public String getTipoRegina() {
		return tipoRegina;
	}
	public void setTipoRegina(String tipoRegina) {
		this.tipoRegina = tipoRegina;
	}
	public Double getAnnoRegina() {
		return annoRegina;
	}
	public void setAnnoRegina(Double annoRegina) {
		this.annoRegina = annoRegina;
	}
	public Double getAnnoAcq() {
		return annoAcq;
	}
	public void setAnnoAcq(Double annoAcq) {
		this.annoAcq = annoAcq;
	}
	public Integer getIdApiario() {
		return idApiario;
	}
	public void setIdApiario(Integer idApiario) {
		this.idApiario = idApiario;
	}
	public Integer getIdTipoArnia() {
		return idTipoArnia;
	}
	public void setIdTipoArnia(Integer idTipoArnia) {
		this.idTipoArnia = idTipoArnia;
	}
	
	@Override
	public String toString() {
		return "Arnia [idArnia=" + idArnia + ", tipoRegina=" + tipoRegina + ", annoRegina=" + annoRegina + ", annoAcq="
				+ annoAcq + ", idApiario=" + idApiario + ", idTipoArnia=" + idTipoArnia + "]";
	}
	
}
