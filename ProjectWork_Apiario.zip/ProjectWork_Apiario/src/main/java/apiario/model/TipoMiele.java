package apiario.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tipo_miele")
public class TipoMiele {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_tipo_miele", nullable=true)
	private Integer idTipoMiele;
	
	@Column(name = "descrizione")
	private String descrizione;

	public Integer getIdTipoMiele() {
		return idTipoMiele;
	}
	public void setIdTipoMiele(Integer idTipoMiele) {
		this.idTipoMiele = idTipoMiele;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	@Override
	public String toString() {
		return "TipoMiele [idTipoMiele=" + idTipoMiele + ", descrizione=" + descrizione + "]";
	}
	
}
