package apiario.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="apiario")
public class Apiario {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_apiario", nullable=true)
	private Integer idApiario;
	
	@Column(name = "indirizzo")
	private String indirizzo;
	
	@Column(name = "long")
	private Float longitudine;

	@Column(name = "lat")
	private Float latitudine;

	public Integer getIdApiario() {
		return idApiario;
	}
	public void setIdApiario(Integer idApiario) {
		this.idApiario = idApiario;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public Float getLongitudine() {
		return longitudine;
	}
	public void setLongitudine(Float longitudine) {
		this.longitudine = longitudine;
	}
	public Float getLatitudine() {
		return latitudine;
	}
	public void setLatitudine(Float latitudine) {
		this.latitudine = latitudine;
	}
	
	@Override
	public String toString() {
		return "Apiario [idApiario=" + idApiario + ", indirizzo=" + indirizzo + ", longitudine=" + longitudine
				+ ", latitudine=" + latitudine + "]";
	}
	
}
