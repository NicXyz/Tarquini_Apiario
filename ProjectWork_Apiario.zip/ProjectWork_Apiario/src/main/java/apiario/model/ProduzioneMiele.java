package apiario.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="produzione_miele")
public class ProduzioneMiele {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_produzione", nullable=true)
	private Integer idProduzione;
	
	@Column(name = "data")
	private Date dataProduzione;
	
	@Column(name = "id_arnia")
	private Integer idArnia;

	@Column(name = "id_tipo_miele")
	private Integer idTipoMiele;
	
	@Column(name = "qta")
	private Integer qta;

	public Integer getIdProduzione() {
		return idProduzione;
	}
	public void setIdProduzione(Integer idProduzione) {
		this.idProduzione = idProduzione;
	}
	public Date getDataProduzione() {
		return dataProduzione;
	}
	public void setDataProduzione(Date dataProduzione) {
		this.dataProduzione = dataProduzione;
	}
	public Integer getIdArnia() {
		return idArnia;
	}
	public void setIdArnia(Integer idArnia) {
		this.idArnia = idArnia;
	}
	public Integer getIdTipoMiele() {
		return idTipoMiele;
	}
	public void setIdTipoMiele(Integer idTipoMiele) {
		this.idTipoMiele = idTipoMiele;
	}
	public Integer getQta() {
		return qta;
	}
	public void setQta(Integer qta) {
		this.qta = qta;
	}
	
	@Override
	public String toString() {
		return "ProduzioneMiele [idProduzione=" + idProduzione + ", dataProduzione=" + dataProduzione + ", idArnia=" + idArnia
				+ ", idTipoMiele=" + idTipoMiele + ", qta=" + qta + "]";
	}
	
}
