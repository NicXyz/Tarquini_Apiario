package apiario.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trattamenti")
public class Trattamenti {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id_trattamenti", nullable=true)
	private Integer idTrattamenti;
	
	@Column(name = "id_arnia")
	private Integer idArnia;
	
	@Column(name = "descrizione")
	private String descrizione;
	
	@Column(name = "data_trattamento")
	private Date dataTrattamento;

	public Integer getIdTrattamenti() {
		return idTrattamenti;
	}
	public void setIdTrattamenti(Integer idTrattamenti) {
		this.idTrattamenti = idTrattamenti;
	}
	public Integer getIdArnia() {
		return idArnia;
	}
	public void setIdArnia(Integer idArnia) {
		this.idArnia = idArnia;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public Date getDataTrattamento() {
		return dataTrattamento;
	}
	public void setDataTrattamento(Date dataTrattamento) {
		this.dataTrattamento = dataTrattamento;
	}
	
	@Override
	public String toString() {
		return "Trattamenti [idTrattamenti=" + idTrattamenti + ", idArnia=" + idArnia + ", descrizione=" + descrizione
				+ ", dataTrattamento=" + dataTrattamento + "]";
	}	
	
}
