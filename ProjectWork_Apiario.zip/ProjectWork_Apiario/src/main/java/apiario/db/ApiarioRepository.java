package apiario.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import apiario.model.Apiario;

@Repository
public interface ApiarioRepository extends CrudRepository<Apiario, Integer> {
	
	Apiario findByIdApiario(Integer idApiario);
	Apiario deleteByIdApiario(Integer idApiario);
	
}
