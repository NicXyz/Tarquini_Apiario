package apiario.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import apiario.model.ProduzioneMiele;

@Repository
public interface ProduzioneMieleRepository extends CrudRepository<ProduzioneMiele, Integer> {
	
	ProduzioneMiele findByIdProduzione(Integer idProduzione);
	ProduzioneMiele deleteByIdProduzione(Integer idProduzione);
	
}
