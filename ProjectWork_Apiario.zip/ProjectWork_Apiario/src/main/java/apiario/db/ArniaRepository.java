package apiario.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import apiario.model.Arnia;

@Repository
public interface ArniaRepository extends CrudRepository<Arnia, Integer> {
	
	Arnia findByIdArnia(Integer idArnia);
	Arnia deleteByIdArnia(Integer idArnia);
	
}
