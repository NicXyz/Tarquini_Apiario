package apiario.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import apiario.model.TipoArnia;

@Repository
public interface TipoArniaRepository extends CrudRepository<TipoArnia, Integer> {

}
