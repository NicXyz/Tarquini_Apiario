package apiario.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import apiario.model.TipoMiele;

@Repository
public interface TipoMieleRepository extends CrudRepository<TipoMiele, Integer> {

}
