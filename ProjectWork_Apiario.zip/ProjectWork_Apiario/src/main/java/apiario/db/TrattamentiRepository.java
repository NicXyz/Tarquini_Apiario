package apiario.db;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import apiario.model.Trattamenti;

@Repository
public interface TrattamentiRepository extends CrudRepository<Trattamenti, Integer> {
	
	Trattamenti findByIdTrattamenti(Integer idTrattamenti);
	Trattamenti deleteByIdTrattamenti(Integer idTrattamenti);
	
}
