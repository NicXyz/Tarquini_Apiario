package apiario.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import apiario.db.ApiarioRepository;
import apiario.model.Apiario;
import apiario.service.ApiarioService;

@RestController
public class ApiarioController {
	
	@Autowired
	ApiarioRepository apiarioRepository;
	
	@Autowired
	ApiarioService apiarioService;
	
	@GetMapping("/apiari")
	public Iterable<Apiario> vediApiari() {
		return apiarioRepository.findAll();
	}
	
	@PostMapping(value="/apiario")
	public Apiario inserisciApiario(@RequestBody Apiario a) {
		return apiarioService.inserisciApiario(a);
	}
	
	@RequestMapping(value="/apiario/{idApiario}", method=RequestMethod.PUT)
	public Apiario modificaApiario(@PathVariable("idApiario")Integer idApiario, @RequestBody Apiario a) {
		return apiarioService.aggiornaApiario(idApiario, a);
	}
	
	@DeleteMapping("/apiario/{idApiario}")
	public Apiario cancellaApiario(@PathVariable("idApiario")Integer idApiario) {
		return apiarioService.eliminaApiario(idApiario);
	}
}
