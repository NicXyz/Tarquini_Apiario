package apiario.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import apiario.db.ProduzioneMieleRepository;
import apiario.model.ProduzioneMiele;
import apiario.service.ProduzioneMieleService;

@RestController
public class ProduzioneMieleController {
	
	@Autowired
	ProduzioneMieleRepository produzioneMieleRepository;
	
	@Autowired
	ProduzioneMieleService produzioneMieleService;
	
	@GetMapping("/produzioni")
	public Iterable<ProduzioneMiele> vediProduzioni() {
		return produzioneMieleRepository.findAll();
	}
	
	@PostMapping(value="/produzione")
	public ProduzioneMiele inserisciProduzione(@RequestBody ProduzioneMiele pm) {
		return produzioneMieleService.inserisciProduzione(pm);
	}
	
	@RequestMapping(value="/produzione/{idProduzione}", method=RequestMethod.PUT)
	public ProduzioneMiele modificaProduzione(@PathVariable("idProduzione")Integer idProduzione, @RequestBody ProduzioneMiele pm) {
		return produzioneMieleService.aggiornaProduzione(idProduzione, pm);
	}
	
	@DeleteMapping("/produzione/{idProduzione}")
	public ProduzioneMiele cancellaProduzione(@PathVariable("idProduzione")Integer idProduzione) {
		return produzioneMieleService.eliminaProduzione(idProduzione);
	}
}
