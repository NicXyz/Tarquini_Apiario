package apiario.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import apiario.db.TrattamentiRepository;
import apiario.model.Trattamenti;
import apiario.service.TrattamentiService;

@RestController
public class TrattamentiController {
	
	@Autowired
	TrattamentiRepository trattamentiRepository;
	
	@Autowired
	TrattamentiService trattamentiService;
	
	@GetMapping("/trattamenti")
	public Iterable<Trattamenti> vediTrattamenti() {
		return trattamentiRepository.findAll();
	}
	
	@PostMapping(value="/trattamento")
	public Trattamenti inserisciTrattamenti(@RequestBody Trattamenti t) {
		return trattamentiService.inserisciTrattamento(t);
	}
	
	@RequestMapping(value="/trattamento/{idTrattamenti}", method=RequestMethod.PUT)
	public Trattamenti modificaTrattamenti(@PathVariable("idTrattamenti")Integer idTrattamenti, @RequestBody Trattamenti t) {
		return trattamentiService.aggiornaTrattamento(idTrattamenti, t);
	}
	
	@DeleteMapping("/trattamento/{idTrattamenti}")
	public Trattamenti cancellaTrattamenti(@PathVariable("idTrattamenti")Integer idTrattamenti) {
		return trattamentiService.eliminaTrattamento(idTrattamenti);
	}
	
	
}
