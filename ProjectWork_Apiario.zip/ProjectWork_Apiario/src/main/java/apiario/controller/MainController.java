package apiario.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
	
	@GetMapping("/")
	public String menu() {
		return "menu";
	}
	@GetMapping("/inserisci")
	public String inviaSceltaInserimento() {
		return "inserisci";
	}
	
	@GetMapping("/liste")
	public String inviaSceltaLista() {
		return "liste";
	}
	
	@GetMapping("/modifica")
	public String inviaSceltaModifica() {
		return "modifica";
	}
	
	@GetMapping("/elimina")
	public String inviaSceltaEliminazione() {
		return "elimina";
	}
	
	@GetMapping("/apiario")
	public String inviaApiario() {
		return "apiario";
	}
	@GetMapping("/arnia")
	public String inviaArnia() {
		return "arnia";
	}
	@GetMapping("/produzione")
	public String inviaProduzione() {
		return "produzione";
	}
	@GetMapping("/trattamento")
	public String inviaTrattamento() {
		return "trattamento";
	}
}


