package apiario.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import apiario.db.ProduzioneMieleRepository;
import apiario.model.ProduzioneMiele;

@Service
public class ProduzioneMieleService {
	
	@Autowired
	ProduzioneMieleRepository produzioneMieleRepository;
	
	public ProduzioneMiele inserisciProduzione(ProduzioneMiele pm) {
		return produzioneMieleRepository.save(pm);
	}
	
	public ProduzioneMiele aggiornaProduzione(Integer id, ProduzioneMiele pm) {
		ProduzioneMiele produzioneDaAggiornare = produzioneMieleRepository.findByIdProduzione(id);
		
		produzioneDaAggiornare.setDataProduzione(pm.getDataProduzione());
		produzioneDaAggiornare.setIdArnia(pm.getIdArnia());
		produzioneDaAggiornare.setIdTipoMiele(pm.getIdTipoMiele());
		produzioneDaAggiornare.setQta(pm.getQta());

		return produzioneMieleRepository.save(produzioneDaAggiornare);
	}
	
	public ProduzioneMiele eliminaProduzione(Integer id) {
		ProduzioneMiele produzioneMiele = produzioneMieleRepository.findById(id).orElse(null);
		if(produzioneMiele!=null) {
			produzioneMieleRepository.delete(produzioneMiele);
			return produzioneMiele;
		} else {
			return null;
		}
	}
}
