package apiario.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import apiario.db.TrattamentiRepository;
import apiario.model.Trattamenti;

@Service
public class TrattamentiService {
	
	@Autowired
	TrattamentiRepository trattamentiRepository;
	
	public Trattamenti inserisciTrattamento(Trattamenti t) {
		return trattamentiRepository.save(t);
	}
	
	public Trattamenti aggiornaTrattamento(Integer id, Trattamenti t) {
		Trattamenti trattamentoDaAggiornare = trattamentiRepository.findByIdTrattamenti(id);
		
		trattamentoDaAggiornare.setIdArnia(t.getIdArnia());
		trattamentoDaAggiornare.setDescrizione(t.getDescrizione());
		trattamentoDaAggiornare.setDataTrattamento(t.getDataTrattamento());

		return trattamentiRepository.save(trattamentoDaAggiornare);
	}
	
	public Trattamenti eliminaTrattamento(Integer id) {
		Trattamenti trattamenti = trattamentiRepository.findById(id).orElse(null);
		if(trattamenti!=null) {
			trattamentiRepository.delete(trattamenti);
			return trattamenti;
		} else {
			return null;
		}
	}
}
