package apiario.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import apiario.db.ApiarioRepository;
import apiario.model.Apiario;

@Service
public class ApiarioService {
	
	@Autowired
	ApiarioRepository apiarioRepository;
	
	public Apiario inserisciApiario(Apiario a) {
		return apiarioRepository.save(a);
	}
	
	public Apiario aggiornaApiario(Integer id, Apiario a) {
		Apiario apiarioDaAggiornare = apiarioRepository.findByIdApiario(id);
		
		apiarioDaAggiornare.setIndirizzo(a.getIndirizzo());
		apiarioDaAggiornare.setLatitudine(a.getLatitudine());
		apiarioDaAggiornare.setLongitudine(a.getLongitudine());

		return apiarioRepository.save(apiarioDaAggiornare);
	}
	
	public Apiario eliminaApiario(Integer id) {
		Apiario apiario = apiarioRepository.findById(id).orElse(null);
		if(apiario!=null) {
			apiarioRepository.delete(apiario);
			return apiario;
		} else {
			return null;
		}	
	}
}
