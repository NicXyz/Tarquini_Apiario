package apiario.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import apiario.db.ArniaRepository;
import apiario.model.Arnia;

@Service
public class ArniaService {

	@Autowired
	ArniaRepository arniaRepository;
	
	public Arnia inserisciArnia(Arnia a) {
		return arniaRepository.save(a);
	}
	
	public Arnia aggiornaArnia(Integer id, Arnia a) {
		Arnia arniaDaAggiornare = arniaRepository.findByIdArnia(id);
		
		arniaDaAggiornare.setTipoRegina(a.getTipoRegina());
		arniaDaAggiornare.setAnnoRegina(a.getAnnoRegina());
		arniaDaAggiornare.setAnnoRegina(a.getAnnoAcq());
		arniaDaAggiornare.setIdApiario(a.getIdApiario());
		arniaDaAggiornare.setIdTipoArnia(a.getIdTipoArnia());

		return arniaRepository.save(arniaDaAggiornare);
	}
	
	public Arnia eliminaArnia(Integer id) {
		Arnia arnia = arniaRepository.findById(id).orElse(null);
		if(arnia!=null) {
			arniaRepository.delete(arnia);
			return arnia;
		} else {
			return null;
		}
	}
}
